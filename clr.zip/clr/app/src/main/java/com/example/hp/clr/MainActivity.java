package com.example.hp.clr;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    Button buttonBlue, buttonRed, buttonYellow, buttonOrange;
    EditText t1;
    String str[],n;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonBlue = (Button) findViewById(R.id.button4);
        buttonRed = (Button) findViewById(R.id.button5);
        buttonOrange = (Button) findViewById(R.id.button8);
        buttonYellow = (Button) findViewById(R.id.button9);
        t1 = (EditText) findViewById(R.id.editText3);


        t1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                n=t1.getText().toString();
                str=n.split(",");
                for (int i = 0; i < str.length; i++) {
                    if (str[i].equals( "blue")){
                        buttonBlue.setBackgroundColor(Color.BLUE);}
                    if (str[i].equals("Red")){
                        buttonRed.setBackgroundColor(Color.RED);}
                    if (str[i].equals( "yellow")){
                        buttonYellow.setBackgroundColor(Color.YELLOW);}
                    if (str[i].equals("orange")){
                        buttonOrange.setBackgroundColor(Color.BLACK);}


                }
            }
        });
    }
}

